package com.lowongankerja.ui.dashboard

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.lowongankerja.data.model.Job
import com.lowongankerja.databinding.ActivityDashboardBinding

class DashboardActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDashboardBinding
    private lateinit var adapter: JobAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        loadDummyData()
    }

    private fun setupRecyclerView() {
        adapter = JobAdapter { job ->
            Toast.makeText(this, "Memilih lowongan: ${job.title}", Toast.LENGTH_SHORT).show()
        }
        binding.recyclerJobs.layoutManager = LinearLayoutManager(this)
        binding.recyclerJobs.adapter = adapter
    }

    private fun loadDummyData() {
        val dummyJobs = listOf(
            Job(1, "Android Developer", "PT Teknologi Nusantara", "Jakarta", "Rp 8.000.000 - Rp 12.000.000"),
            Job(2, "UI/UX Designer", "Studio Digital Kreatif", "Bandung", "Rp 6.000.000 - Rp 9.000.000"),
            Job(3, "Backend Engineer", "Global Data Utama", "Surabaya", "Rp 10.000.000 - Rp 15.000.000"),
            Job(4, "Data Analyst", "Fintech Indonesia", "Remote", "Rp 7.500.000 - Rp 11.000.000"),
            Job(5, "QA Engineer", "Solusi Sistem", "Yogyakarta", "Rp 5.500.000 - Rp 8.000.000")
        )
        adapter.submitList(dummyJobs)
    }
}