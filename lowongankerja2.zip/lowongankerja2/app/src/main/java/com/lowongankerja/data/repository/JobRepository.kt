package com.lowongankerja.data.repository

import com.lowongankerja.data.api.RetrofitClient
import com.lowongankerja.data.model.Job

class JobRepository {
    suspend fun getJobs(token: String): List<Job> {
        return RetrofitClient.jobService.getJobs("Bearer $token")
    }
}